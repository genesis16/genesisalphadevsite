# freelancer-child

## Installation

1. Upload the entire 'freelancer-child' folder to the '/wp-content/themes/' directory -- or just upload the ZIP package via 'Appearance > Themes > Add New > Upload Theme' in your WP Admin
2. Activate the Theme through the 'Appearance > Themes' menu in WordPress
3. That's it!

### Freelancer Support & Resources

https://cobaltapps.com/my-account/

### Contact Us

https://cobaltapps.com/contact-us/
