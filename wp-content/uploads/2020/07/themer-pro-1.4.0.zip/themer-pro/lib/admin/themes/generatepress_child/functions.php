<?php
/**
 * Generate child theme functions and definitions
 *
 * @package Generate
 */
