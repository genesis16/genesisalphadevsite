# themer-pro

## Installation

1. Upload the entire 'themer-pro' folder to the '/wp-content/plugins/' directory -- or just upload the ZIP package via 'Plugins > Add New > Upload' in your WP Admin
2. Activate the plugin through the 'Plugins' menu in WordPress
3. In your left-hand WordPress sidebar you'll find the Themer Pro admin pages, showing that the Plugin was successfully installed and activated
4. That's it!

### Cobalt Apps Support & Resources

https://cobaltapps.com/my-account/

### Contact Us

https://cobaltapps.com/contact-us/
